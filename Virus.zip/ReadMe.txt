its a fake virus

passwort is VIRUS

shutdown your antivirus